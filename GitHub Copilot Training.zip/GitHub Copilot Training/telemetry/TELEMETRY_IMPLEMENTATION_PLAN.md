# Telemetry POC Implementation Plan

## Goal

Implement the contract in [VEHICLE_TELEMETRY_POC.md](VEHICLE_TELEMETRY_POC.md) as a small, testable telemetry pipeline for the electric two-wheeler dashboard. Keep the simulator deterministic in tests and keep the HMI runnable after every phase.

The data path will be:

`simulator -> TelemetrySnapshot -> dashboard presenter -> widgets`

The POC remains in-process. It does not connect to CAN, vehicle hardware, a network service, or persistent storage.

## Working Rules

- Use Python's standard-library `unittest` so the test suite adds no test dependency.
- Keep model and simulator code independent of PySide6; Qt is only needed for dashboard integration tests and the app.
- Preserve `UI.py` as the launch entry point.
- Each phase ends with its listed test gate passing before the next phase begins.
- Avoid safety-critical behavior: warnings are display-only and simulated range is not a validated estimate.

## Proposed File Layout

```text
UI.py
requirements.txt
telemetry/
    VEHICLE_TELEMETRY_POC.md
    TELEMETRY_IMPLEMENTATION_PLAN.md
    __init__.py
    model.py
    simulator.py
tests/
    test_telemetry_model.py
    test_telemetry_simulator.py
    test_dashboard_telemetry.py
    fixtures/
        normal_snapshot.json
```

## Phase 0: Establish a Baseline

**Purpose:** Make sure the current app is a known-good starting point and put a repeatable test entry point in place before changing behavior.

**Work:**
- Record the current launch and smoke-test commands.
- Create the `tests/` package/layout and a minimal test proving test discovery works.
- Keep the current sample telemetry and UI behavior unchanged.

**Independent checks:**
- `python -m py_compile UI.py`
- `python -m unittest discover -s tests`
- Launch `python UI.py` and confirm the dashboard opens.

**Exit gate:** Baseline checks pass; no visual or runtime regression is introduced.

## Phase 1: Add the Typed Telemetry Contract

**Purpose:** Represent one validated POC snapshot without depending on UI code or Qt.

**Work:**
- Add `telemetry/model.py` with immutable `TelemetrySnapshot` and `WarningStatus` data types.
- Add a conversion function from a JSON-shaped dictionary to those types.
- Validate enum values and numeric ranges from the spec (speed, state of charge, regen level, and non-negative distance/consumption).
- Keep missing or invalid individual measurements distinguishable from a real zero so the UI can show `--` / `UNAVAILABLE`; do not silently coerce them to zero.
- Add a normal example fixture that matches the spec. Define and test the POC policy for malformed fields: retain valid fields, mark invalid/missing measurements unavailable, and use an explicit warning/error state for an invalid warning object.

**Independent checks:**
- `python -m unittest discover -s tests -p "test_telemetry_model.py"`
- Cover valid fixture parsing, enum/range boundaries, missing fields, invalid types, and preservation of valid fields when another field is bad.

**Exit gate:** The model tests pass without importing PySide6; fixture values and field names match the approved spec.

## Phase 2: Implement a Deterministic Simulator

**Purpose:** Generate realistic-enough demo snapshots with repeatable unit tests.

**Work:**
- Add `telemetry/simulator.py` with a simulator that produces one `TelemetrySnapshot` per call.
- Increment `sequence`, generate UTC timestamps, keep all values inside contract bounds, and vary speed/indicators predictably.
- Simulate battery/range and warning transitions at controlled thresholds; allow an explicit initial state or tick input so tests do not rely on sleeping or wall-clock timing.
- Keep the one-second scheduling responsibility outside the simulator.

**Independent checks:**
- `python -m unittest discover -s tests -p "test_telemetry_simulator.py"`
- Assert sequence/timestamp behavior, valid ranges, deterministic output for the same initial state/ticks, indicator changes, and normal-to-caution warning transition.

**Exit gate:** Simulator tests pass headlessly and generated snapshots always satisfy the model contract.

## Phase 3: Connect Snapshots to the Dashboard

**Purpose:** Replace dashboard-owned hard-coded telemetry updates with a clear snapshot-to-view boundary.

**Work:**
- Add `Dashboard.apply_snapshot(snapshot)` in `UI.py` (or a small presenter module if mapping grows beyond a handful of fields).
- Have the existing `QTimer` request the next simulator snapshot and pass it to `apply_snapshot`.
- Map speed, battery, range, trip, odometer, consumption, regen, and every boolean status lamp from the snapshot.
- Keep display formatting at the UI boundary; keep units in field names and labels.
- Ensure the initial dashboard frame is populated from the first snapshot rather than a separate set of duplicated constants.

**Independent checks:**
- `QT_QPA_PLATFORM=offscreen python -m unittest discover -s tests -p "test_dashboard_telemetry.py"` (PowerShell: `$env:QT_QPA_PLATFORM='offscreen'; python -m unittest discover -s tests -p 'test_dashboard_telemetry.py'`).
- Construct the dashboard with a known snapshot and assert representative labels, gauge value, selected mode, battery bar, and active/inactive lamps.
- Feed a second snapshot and assert that displayed values change accordingly.

**Exit gate:** UI tests pass without showing a window; the app still launches normally and no telemetry display remains driven by an unrelated hard-coded update path.

## Phase 4: Complete Warning and Unavailable States

**Purpose:** Exercise the contract's non-normal cases and avoid misleading displays when data is missing.

**Work:**
- Bind warning level, code, and message to the existing warning strip.
- Render `normal`, `caution`, and `critical` with distinct text/icon plus color, not color alone.
- Render missing/invalid measurements as `--` or an explicit unavailable state; preserve other valid fields in the same snapshot.
- Define a simple stale-data behavior for the POC if the update loop stops (for example, show `NO DATA` after a short timeout). This is display-only and must not imply a production fault strategy.
- Check that low battery and a side stand down state are conspicuous without changing vehicle controls.

**Independent checks:**
- Extend model and dashboard tests with normal, caution, critical, missing-field, invalid-field, and stale-data cases.
- Assert warning copy and severity indicator, and assert unavailable values are not displayed as zero.

**Exit gate:** Every POC warning level and unavailable-data behavior has a passing automated test.

## Phase 5: End-to-End POC Acceptance

**Purpose:** Confirm the integrated demo satisfies the approved contract and remains usable as a dashboard.

**Work:**
- Run all unit and offscreen UI tests together.
- Launch the app and observe multiple 1 Hz updates.
- Resize the window across its supported range; verify speed, battery, statuses, and warning text remain legible and do not overlap.
- Check Eco/Ride/Sport selection updates the UI and simulator state consistently. Keep mode selection a local demo control; it does not command a vehicle.
- Update the spec only for implementation decisions that genuinely clarify the agreed POC behavior.

**Independent checks:**
- `python -m unittest discover -s tests`
- `python UI.py` followed by the manual visual and resize checklist above.

**Exit gate:** Automated suite passes, dashboard launches, and each field in the approved POC snapshot is either displayed or intentionally used to derive a visible status.

## Phase Dependencies and Delivery Order

Phases are intentionally sequential: Phase 1 creates the data boundary, Phase 2 supplies it, Phase 3 consumes it, and Phase 4 expands UI behavior for edge states. Phase 0 and each later phase have their own checks, so a phase can be reviewed and verified before moving forward. Phase 5 is the integrated acceptance pass, not a substitute for phase-level tests.

## Explicit POC Limits

- No CAN decoding, vehicle hardware, or actual controls.
- No claim of safe-to-ride, safety certification, validated range, or production-grade warning behavior.
- No network/API protocol, persistence, authentication, or cloud service.
- Simulated values are solely for exercising the dashboard and its tests.
