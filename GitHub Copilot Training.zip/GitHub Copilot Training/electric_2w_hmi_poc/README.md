# Electric Two-Wheeler HMI POC

A desktop instrument-cluster prototype built with PySide6. The dashboard reads typed snapshots from an in-process simulator; it does not connect to a vehicle, CAN bus, or network service.

## Run

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python UI_new.py
```

## Test

```powershell
$env:QT_QPA_PLATFORM = "offscreen"
python -m unittest discover -s tests
Remove-Item Env:QT_QPA_PLATFORM
```

The telemetry model and simulator tests do not require a display. The dashboard tests use Qt's offscreen platform plugin.

## Project Layout

- `UI_new.py`: HMI window and snapshot-to-widget presentation.
- `telemetry/model.py`: validated, Qt-independent telemetry dataclasses and JSON-shaped mapping conversion.
- `telemetry/simulator.py`: deterministic demo values and warning transitions.
- `tests/`: model, simulator, and offscreen dashboard tests.

The workspace-level POC contract and phased plan are in `../telemetry/VEHICLE_TELEMETRY_POC.md` and `../telemetry/TELEMETRY_IMPLEMENTATION_PLAN.md`.

This is a visual/software POC only. Telemetry is simulated; warnings and range estimates are not validated for vehicle operation and must not be used to make riding decisions.