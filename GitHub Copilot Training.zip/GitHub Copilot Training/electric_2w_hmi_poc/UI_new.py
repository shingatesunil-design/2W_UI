import math
import sys
from datetime import datetime

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QColor, QFont, QPainter, QPen
from PySide6.QtWidgets import (
	QApplication,
	QButtonGroup,
	QFrame,
	QGridLayout,
	QHBoxLayout,
	QLabel,
	QMainWindow,
	QProgressBar,
	QPushButton,
	QSizePolicy,
	QVBoxLayout,
	QWidget,
)

from telemetry import TelemetrySimulator


COLORS = {
	"background": "#0a1116",
	"panel": "#111c22",
	"panel_light": "#17262d",
	"line": "#263940",
	"text": "#edf5f3",
	"muted": "#8fa4a8",
	"teal": "#51dfc1",
	"green": "#8be28b",
	"amber": "#f2bd63",
	"red": "#f07171",
}


class SpeedGauge(QWidget):
	def __init__(self, parent=None):
		super().__init__(parent)
		self.speed = None
		self.setMinimumSize(250, 250)
		self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)

	def set_speed(self, speed):
		self.speed = speed
		self.update()

	def paintEvent(self, event):
		del event
		painter = QPainter(self)
		painter.setRenderHint(QPainter.RenderHint.Antialiasing)
		side = min(self.width(), self.height())
		center = self.rect().center()
		radius = side * 0.37
		arc_rect = self.rect().adjusted(
			int(self.width() / 2 - radius),
			int(self.height() / 2 - radius),
			int(self.width() / 2 + radius),
			int(self.height() / 2 + radius),
		)
		start_angle = 225 * 16
		span_angle = -270 * 16
		painter.setPen(QPen(QColor(COLORS["line"]), max(8, side * 0.03), Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
		painter.drawArc(arc_rect, start_angle, span_angle)
		if self.speed is not None:
			progress = min(max(self.speed, 0), 120) / 120
			painter.setPen(QPen(QColor(COLORS["teal"]), max(8, side * 0.03), Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
			painter.drawArc(arc_rect, start_angle, int(span_angle * progress))

		for tick in range(13):
			angle = math.radians(135 + tick * 22.5)
			outer = radius + side * 0.05
			inner = radius + side * (0.012 if tick % 3 == 0 else 0.026)
			painter.setPen(QPen(QColor(COLORS["muted"]), max(1, side * 0.004)))
			painter.drawLine(
				int(center.x() + math.cos(angle) * inner),
				int(center.y() + math.sin(angle) * inner),
				int(center.x() + math.cos(angle) * outer),
				int(center.y() + math.sin(angle) * outer),
			)

		painter.setPen(QColor(COLORS["text"]))
		painter.setFont(QFont("Bahnschrift", max(34, int(side * 0.22)), QFont.Weight.DemiBold))
		painter.drawText(self.rect().adjusted(0, int(side * 0.13), 0, -int(side * 0.08)), Qt.AlignmentFlag.AlignCenter, self._speed_text())
		painter.setPen(QColor(COLORS["muted"]))
		painter.setFont(QFont("Bahnschrift", max(10, int(side * 0.045)), QFont.Weight.Medium))
		painter.drawText(self.rect().adjusted(0, int(side * 0.42), 0, 0), Qt.AlignmentFlag.AlignCenter, "km/h")

	def _speed_text(self):
		return "--" if self.speed is None else str(round(self.speed))


class MetricTile(QFrame):
	def __init__(self, title, suffix="", accent=None, parent=None):
		super().__init__(parent)
		self.setObjectName("metricTile")
		layout = QVBoxLayout(self)
		layout.setContentsMargins(15, 11, 15, 11)
		layout.setSpacing(4)
		title_label = QLabel(title.upper())
		title_label.setObjectName("eyebrow")
		self.value_label = QLabel("--")
		self.value_label.setObjectName("metricValue")
		if accent:
			self.value_label.setStyleSheet(f"color: {accent};")
		suffix_label = QLabel(suffix)
		suffix_label.setObjectName("metricSuffix")
		layout.addWidget(title_label)
		row = QHBoxLayout()
		row.setSpacing(6)
		row.addWidget(self.value_label)
		row.addWidget(suffix_label, 0, Qt.AlignmentFlag.AlignBottom)
		row.addStretch(1)
		layout.addLayout(row)

	def set_value(self, value):
		self.value_label.setText(str(value))


class StatusLamp(QFrame):
	def __init__(self, symbol, label, color=None, parent=None):
		super().__init__(parent)
		self.setObjectName("statusLamp")
		self.color = color or COLORS["teal"]
		layout = QHBoxLayout(self)
		layout.setContentsMargins(9, 8, 9, 8)
		layout.setSpacing(7)
		self.symbol_label = QLabel(symbol)
		self.symbol_label.setObjectName("lampSymbol")
		self.text_label = QLabel(label)
		self.text_label.setObjectName("lampText")
		layout.addWidget(self.symbol_label)
		layout.addWidget(self.text_label)
		self.set_active(False)

	def set_active(self, active, label=None, color=None):
		active_color = color or self.color
		self.symbol_label.setStyleSheet(f"color: {active_color if active else COLORS['muted']}; font-weight: 700;")
		self.text_label.setStyleSheet(f"color: {COLORS['text'] if active else COLORS['muted']};")
		if label is not None:
			self.text_label.setText(label)


class Dashboard(QMainWindow):
	def __init__(self, simulator=None):
		super().__init__()
		self.setWindowTitle("VOLT | Electric Two-Wheeler")
		self.setMinimumSize(980, 600)
		self.resize(1280, 760)
		self.simulator = simulator or TelemetrySimulator()
		self.setStyleSheet(f"""
			QWidget {{ background: {COLORS['background']}; color: {COLORS['text']}; font-family: 'Bahnschrift', 'Segoe UI', sans-serif; }}
			QFrame#metricTile, QFrame#statusLamp {{ background: {COLORS['panel']}; border: 1px solid {COLORS['line']}; border-radius: 8px; }}
			QLabel#eyebrow {{ color: {COLORS['muted']}; font-size: 10px; font-weight: 700; letter-spacing: 1px; }}
			QLabel#metricValue {{ font-size: 24px; font-weight: 600; }}
			QLabel#metricSuffix {{ color: {COLORS['muted']}; font-size: 12px; padding-bottom: 3px; }}
			QLabel#lampSymbol {{ font-size: 15px; }}
			QLabel#lampText {{ font-size: 10px; font-weight: 600; }}
			QPushButton {{ background: {COLORS['panel_light']}; color: {COLORS['muted']}; border: 1px solid {COLORS['line']}; border-radius: 6px; padding: 9px 14px; font-size: 12px; font-weight: 700; }}
			QPushButton:checked {{ background: #173c3a; color: {COLORS['teal']}; border: 1px solid {COLORS['teal']}; }}
			QProgressBar {{ background: {COLORS['line']}; border: none; border-radius: 5px; height: 12px; }}
			QProgressBar::chunk {{ background: {COLORS['green']}; border-radius: 5px; }}
		""")

		root = QWidget()
		self.setCentralWidget(root)
		layout = QVBoxLayout(root)
		layout.setContentsMargins(24, 18, 24, 18)
		layout.setSpacing(14)
		layout.addLayout(self._build_header())
		layout.addLayout(self._build_status_row())
		layout.addLayout(self._build_main_content(), 1)
		layout.addWidget(self._build_warning_bar())

		self.apply_snapshot(self.simulator.next_snapshot())
		self.timer = QTimer(self)
		self.timer.timeout.connect(self.update_telemetry)
		self.timer.start(1000)

	def _build_header(self):
		row = QHBoxLayout()
		brand = QVBoxLayout()
		brand_title = QLabel("VOLT  /  E-2W")
		brand_title.setStyleSheet(f"font-size: 17px; font-weight: 800; color: {COLORS['teal']};")
		brand_subtitle = QLabel("ELECTRIC DRIVE SYSTEM")
		brand_subtitle.setObjectName("eyebrow")
		brand.addWidget(brand_title)
		brand.addWidget(brand_subtitle)
		row.addLayout(brand)
		row.addStretch(1)
		self.ready_badge = QLabel("VEHICLE READY")
		self.clock_label = QLabel("")
		self.clock_label.setStyleSheet(f"color: {COLORS['muted']}; font-size: 14px; font-weight: 600; margin-left: 10px;")
		row.addWidget(self.ready_badge)
		row.addWidget(self.clock_label)
		return row

	def _build_status_row(self):
		row = QHBoxLayout()
		row.setSpacing(7)
		self.lamps = {
			"left": StatusLamp("◀", "LEFT", COLORS["green"]),
			"right": StatusLamp("▶", "RIGHT", COLORS["green"]),
			"headlight": StatusLamp("◉", "HEADLIGHT", COLORS["teal"]),
			"highbeam": StatusLamp("✦", "HIGH BEAM", COLORS["teal"]),
			"stand": StatusLamp("▰", "SIDE STAND", COLORS["amber"]),
			"connection": StatusLamp("⌁", "CONNECTED", COLORS["teal"]),
		}
		for lamp in self.lamps.values():
			row.addWidget(lamp)
		return row

	def _build_main_content(self):
		row = QHBoxLayout()
		row.setSpacing(16)
		gauge_panel = QFrame()
		gauge_panel.setObjectName("metricTile")
		gauge_layout = QVBoxLayout(gauge_panel)
		gauge_layout.setContentsMargins(18, 14, 18, 14)
		gauge_heading = QLabel("ROAD SPEED")
		gauge_heading.setObjectName("eyebrow")
		gauge_layout.addWidget(gauge_heading, 0, Qt.AlignmentFlag.AlignHCenter)
		self.speed_gauge = SpeedGauge()
		gauge_layout.addWidget(self.speed_gauge, 1)
		self.mode_label = QLabel("RIDE MODE  /  RIDE")
		self.mode_label.setStyleSheet(f"color: {COLORS['teal']}; font-size: 11px; font-weight: 700; letter-spacing: 1px;")
		gauge_layout.addWidget(self.mode_label, 0, Qt.AlignmentFlag.AlignHCenter)
		row.addWidget(gauge_panel, 5)

		right = QVBoxLayout()
		right.setSpacing(10)
		battery_panel = QFrame()
		battery_panel.setObjectName("metricTile")
		battery_layout = QVBoxLayout(battery_panel)
		battery_layout.setContentsMargins(17, 12, 17, 12)
		battery_top = QHBoxLayout()
		battery_title = QLabel("BATTERY")
		battery_title.setObjectName("eyebrow")
		self.battery_percent = QLabel("--")
		self.battery_percent.setStyleSheet(f"color: {COLORS['green']}; font-size: 25px; font-weight: 700;")
		battery_top.addWidget(battery_title)
		battery_top.addStretch(1)
		battery_top.addWidget(self.battery_percent)
		battery_layout.addLayout(battery_top)
		self.battery_bar = QProgressBar()
		self.battery_bar.setRange(0, 100)
		self.battery_bar.setTextVisible(False)
		battery_layout.addWidget(self.battery_bar)
		battery_bottom = QHBoxLayout()
		battery_bottom.addWidget(QLabel("EST. RANGE"))
		battery_bottom.addStretch(1)
		self.range_label = QLabel("-- km")
		self.range_label.setStyleSheet(f"font-size: 18px; font-weight: 700;")
		battery_bottom.addWidget(self.range_label)
		battery_layout.addLayout(battery_bottom)
		right.addWidget(battery_panel)

		mode_panel = QFrame()
		mode_panel.setObjectName("metricTile")
		mode_layout = QVBoxLayout(mode_panel)
		mode_layout.setContentsMargins(17, 11, 17, 11)
		mode_title = QLabel("RIDE MODE")
		mode_title.setObjectName("eyebrow")
		mode_layout.addWidget(mode_title)
		mode_row = QHBoxLayout()
		mode_row.setSpacing(7)
		self.mode_group = QButtonGroup(self)
		self.mode_group.setExclusive(True)
		self.mode_buttons = {}
		for mode in ("ECO", "RIDE", "SPORT"):
			button = QPushButton(mode)
			button.setCheckable(True)
			button.clicked.connect(lambda checked, selected=mode: self.set_mode(selected))
			self.mode_group.addButton(button)
			self.mode_buttons[mode] = button
			mode_row.addWidget(button)
		mode_layout.addLayout(mode_row)
		right.addWidget(mode_panel)

		metrics = QGridLayout()
		metrics.setSpacing(9)
		self.trip_tile = MetricTile("Trip A", "km")
		self.odo_tile = MetricTile("Odometer", "km")
		self.consumption_tile = MetricTile("Consumption", "Wh/km", COLORS["teal"])
		self.regen_tile = MetricTile("Regen")
		metrics.addWidget(self.trip_tile, 0, 0)
		metrics.addWidget(self.odo_tile, 0, 1)
		metrics.addWidget(self.consumption_tile, 1, 0)
		metrics.addWidget(self.regen_tile, 1, 1)
		right.addLayout(metrics, 1)
		row.addLayout(right, 6)
		return row

	def _build_warning_bar(self):
		frame = QFrame()
		self.warning_bar = frame
		frame.setObjectName("warningBar")
		layout = QHBoxLayout(frame)
		layout.setContentsMargins(12, 9, 12, 9)
		layout.setSpacing(9)
		self.warning_icon = QLabel("●")
		self.warning_title = QLabel("WARNING DATA UNAVAILABLE")
		self.warning_message = QLabel("")
		layout.addWidget(self.warning_icon)
		layout.addWidget(self.warning_title)
		layout.addWidget(self.warning_message)
		layout.addStretch(1)
		self.trip_footer = QLabel("TRIP A   -- km")
		self.trip_footer.setStyleSheet(f"color: {COLORS['muted']}; font-size: 10px; font-weight: 700;")
		layout.addWidget(self.trip_footer)
		return frame

	def set_mode(self, mode):
		self.simulator.set_mode(mode)
		self.mode_label.setText(f"RIDE MODE  /  {mode}")

	def update_telemetry(self):
		self.apply_snapshot(self.simulator.next_snapshot())

	def apply_snapshot(self, snapshot):
		self.snapshot = snapshot
		self.speed_gauge.set_speed(snapshot.speed_kph)
		self.battery_percent.setText(self._format(snapshot.battery_soc_pct, "%", 0))
		self.battery_bar.setVisible(snapshot.battery_soc_pct is not None)
		self.battery_bar.setValue(round(snapshot.battery_soc_pct or 0))
		self.battery_bar.setFormat("" if snapshot.battery_soc_pct is not None else "UNAVAILABLE")
		self.range_label.setText(self._format(snapshot.estimated_range_km, " km", 0))
		self.trip_tile.set_value(self._format(snapshot.trip_a_km, decimals=1))
		self.odo_tile.set_value(self._format(snapshot.odometer_km, decimals=0))
		self.consumption_tile.set_value(self._format(snapshot.consumption_wh_km, decimals=0))
		self.regen_tile.set_value("--" if snapshot.regen_level is None else f"LEVEL {snapshot.regen_level}")
		self.trip_footer.setText(f"TRIP A   {self._format(snapshot.trip_a_km, ' km', 1)}")
		self.clock_label.setText(datetime.now().strftime("%H:%M"))

		for mode, button in self.mode_buttons.items():
			button.setChecked(mode == snapshot.ride_mode)
		self.mode_label.setText(f"RIDE MODE  /  {snapshot.ride_mode or 'UNAVAILABLE'}")
		self._set_lamp("left", snapshot.left_indicator)
		self._set_lamp("right", snapshot.right_indicator)
		self._set_lamp("headlight", snapshot.headlight_on)
		self._set_lamp("highbeam", snapshot.high_beam_on)
		self._set_lamp("stand", snapshot.side_stand_down, "STAND DOWN" if snapshot.side_stand_down else "SIDE STAND")
		self._set_lamp("connection", snapshot.connected, "CONNECTED" if snapshot.connected else "OFFLINE")
		ready_color = COLORS["green"] if snapshot.vehicle_ready else COLORS["amber"]
		ready_text = "VEHICLE READY" if snapshot.vehicle_ready else "NOT READY"
		self.ready_badge.setText(ready_text if snapshot.vehicle_ready is not None else "READY STATE UNKNOWN")
		self.ready_badge.setStyleSheet(f"color: {ready_color}; font-size: 11px; font-weight: 700; padding: 8px 12px; background: {COLORS['panel']}; border-radius: 6px;")
		self._set_warning(snapshot.warning)

	def _set_lamp(self, name, active, label=None):
		lamp = self.lamps[name]
		lamp.set_active(bool(active), label)
		if active is None:
			lamp.text_label.setText("UNAVAILABLE")

	def _set_warning(self, warning):
		if warning is None:
			level, title, message, color = "unknown", "WARNING DATA UNAVAILABLE", "", COLORS["amber"]
		elif warning.level == "normal":
			level, title, message, color = "normal", "SYSTEM NORMAL", warning.message, COLORS["green"]
		elif warning.level == "caution":
			level, title, message, color = "caution", "CAUTION", warning.message, COLORS["amber"]
		else:
			level, title, message, color = "critical", "CRITICAL WARNING", warning.message, COLORS["red"]
		self.warning_bar.setProperty("severity", level)
		self.warning_bar.setStyleSheet(f"QFrame#warningBar {{ background: {COLORS['panel']}; border: 1px solid {color}; border-radius: 7px; }}")
		self.warning_icon.setText("✓" if level == "normal" else "!" if level in {"caution", "critical"} else "?")
		self.warning_icon.setStyleSheet(f"color: {color}; font-size: 16px; font-weight: 800;")
		self.warning_title.setText(title)
		self.warning_title.setStyleSheet(f"color: {color}; font-size: 11px; font-weight: 800; letter-spacing: 1px;")
		self.warning_message.setText(message)
		self.warning_message.setStyleSheet(f"color: {COLORS['muted']}; font-size: 11px;")

	@staticmethod
	def _format(value, suffix="", decimals=0):
		if value is None:
			return "--" if not suffix else f"--{suffix}"
		formatted = f"{value:,.{decimals}f}"
		return f"{formatted}{suffix}"


def main():
	app = QApplication(sys.argv)
	app.setStyle("Fusion")
	window = Dashboard()
	window.show()
	return app.exec()


if __name__ == "__main__":
	sys.exit(main())