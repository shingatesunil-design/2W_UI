import unittest
from dataclasses import replace
from datetime import datetime, timezone

from PySide6.QtWidgets import QApplication

from telemetry import TelemetrySimulator, WarningStatus
from UI_new import Dashboard


class DashboardTelemetryTests(unittest.TestCase):
	@classmethod
	def setUpClass(cls):
		cls.app = QApplication.instance() or QApplication([])

	def setUp(self):
		self.dashboard = Dashboard(TelemetrySimulator())

	def tearDown(self):
		self.dashboard.close()

	def test_initial_view_uses_a_telemetry_snapshot(self):
		snapshot = self.dashboard.snapshot
		self.assertEqual(self.dashboard.speed_gauge.speed, snapshot.speed_kph)
		self.assertEqual(self.dashboard.battery_bar.value(), snapshot.battery_soc_pct)
		self.assertEqual(self.dashboard.mode_label.text(), f"RIDE MODE  /  {snapshot.ride_mode}")

	def test_snapshot_updates_metrics_status_and_warning(self):
		snapshot = replace(
			self.dashboard.snapshot,
			speed_kph=55,
			battery_soc_pct=35,
			estimated_range_km=44,
			ride_mode="SPORT",
			regen_level=1,
			left_indicator=True,
			headlight_on=False,
			side_stand_down=True,
			connected=False,
			warning=WarningStatus("caution", "LOW_BATTERY", "Battery low"),
		)
		self.dashboard.apply_snapshot(snapshot)
		self.assertEqual(self.dashboard.speed_gauge.speed, 55)
		self.assertEqual(self.dashboard.battery_percent.text(), "35%")
		self.assertEqual(self.dashboard.range_label.text(), "44 km")
		self.assertEqual(self.dashboard.regen_tile.value_label.text(), "LEVEL 1")
		self.assertTrue(self.dashboard.lamps["left"].text_label.text() == "LEFT")
		self.assertEqual(self.dashboard.lamps["stand"].text_label.text(), "STAND DOWN")
		self.assertEqual(self.dashboard.lamps["connection"].text_label.text(), "OFFLINE")
		self.assertEqual(self.dashboard.warning_title.text(), "CAUTION")
		self.assertEqual(self.dashboard.warning_message.text(), "Battery low")
		self.assertTrue(self.dashboard.mode_buttons["SPORT"].isChecked())

	def test_missing_values_render_as_unavailable(self):
		snapshot = replace(
			self.dashboard.snapshot,
			speed_kph=None,
			battery_soc_pct=None,
			estimated_range_km=None,
			warning=None,
		)
		self.dashboard.apply_snapshot(snapshot)
		self.assertEqual(self.dashboard.speed_gauge._speed_text(), "--")
		self.assertEqual(self.dashboard.battery_percent.text(), "--%")
		self.assertTrue(self.dashboard.battery_bar.isHidden())
		self.assertEqual(self.dashboard.range_label.text(), "-- km")
		self.assertEqual(self.dashboard.warning_title.text(), "WARNING DATA UNAVAILABLE")


if __name__ == "__main__":
	unittest.main()