import unittest
from datetime import datetime, timezone

from telemetry.simulator import TelemetrySimulator


FIXED_TIME = datetime(2026, 10, 5, 14, 32, 10, tzinfo=timezone.utc)


class TelemetrySimulatorTests(unittest.TestCase):
	def test_sequence_and_ranges(self):
		simulator = TelemetrySimulator()
		first = simulator.next_snapshot(FIXED_TIME)
		second = simulator.next_snapshot(FIXED_TIME)
		self.assertEqual((first.sequence, second.sequence), (1, 2))
		self.assertEqual(first.timestamp, "2026-10-05T14:32:10Z")
		self.assertGreaterEqual(second.speed_kph, 0)
		self.assertLessEqual(second.speed_kph, 120)
		self.assertGreaterEqual(second.battery_soc_pct, 0)
		self.assertLessEqual(second.battery_soc_pct, 100)

	def test_same_state_and_time_are_reproducible(self):
		first = TelemetrySimulator(initial_tick=17).next_snapshot(FIXED_TIME)
		second = TelemetrySimulator(initial_tick=17).next_snapshot(FIXED_TIME)
		self.assertEqual(first, second)

	def test_indicator_and_warning_transitions(self):
		indicator_snapshot = TelemetrySimulator(initial_tick=35).next_snapshot(FIXED_TIME)
		self.assertTrue(indicator_snapshot.left_indicator)

		caution = TelemetrySimulator(initial_tick=58 * 60 - 1).next_snapshot(FIXED_TIME)
		critical = TelemetrySimulator(initial_tick=68 * 60 - 1).next_snapshot(FIXED_TIME)
		self.assertEqual(caution.warning.level, "caution")
		self.assertEqual(critical.warning.level, "critical")

	def test_mode_is_carried_into_snapshot(self):
		simulator = TelemetrySimulator()
		simulator.set_mode("SPORT")
		self.assertEqual(simulator.next_snapshot(FIXED_TIME).ride_mode, "SPORT")


if __name__ == "__main__":
	unittest.main()