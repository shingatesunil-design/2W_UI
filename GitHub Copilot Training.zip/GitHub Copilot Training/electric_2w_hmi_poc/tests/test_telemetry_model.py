import unittest

from telemetry.model import TelemetrySnapshot


VALID_SNAPSHOT = {
	"timestamp": "2026-10-05T14:32:10Z",
	"sequence": 42,
	"source": "simulator",
	"speed_kph": 42,
	"battery_soc_pct": 78,
	"estimated_range_km": 96,
	"ride_mode": "RIDE",
	"regen_level": 2,
	"trip_a_km": 24.6,
	"odometer_km": 3842.0,
	"consumption_wh_km": 31,
	"left_indicator": False,
	"right_indicator": False,
	"headlight_on": True,
	"high_beam_on": False,
	"side_stand_down": False,
	"vehicle_ready": True,
	"connected": True,
	"warning": {"level": "normal", "code": None, "message": "All systems normal"},
}


class TelemetryModelTests(unittest.TestCase):
	def test_parses_valid_snapshot(self):
		snapshot = TelemetrySnapshot.from_mapping(VALID_SNAPSHOT)
		self.assertEqual(snapshot.speed_kph, 42.0)
		self.assertEqual(snapshot.ride_mode, "RIDE")
		self.assertEqual(snapshot.warning.level, "normal")

	def test_invalid_measurements_are_unavailable_not_zero(self):
		data = {**VALID_SNAPSHOT, "speed_kph": 150, "battery_soc_pct": "78", "high_beam_on": 1}
		snapshot = TelemetrySnapshot.from_mapping(data)
		self.assertIsNone(snapshot.speed_kph)
		self.assertIsNone(snapshot.battery_soc_pct)
		self.assertIsNone(snapshot.high_beam_on)
		self.assertEqual(snapshot.odometer_km, 3842.0)

	def test_invalid_envelope_is_rejected(self):
		with self.assertRaises(ValueError):
			TelemetrySnapshot.from_mapping({**VALID_SNAPSHOT, "sequence": -1})
		with self.assertRaises(ValueError):
			TelemetrySnapshot.from_mapping({**VALID_SNAPSHOT, "timestamp": "2026-10-05T14:32:10"})

	def test_invalid_warning_is_unavailable(self):
		snapshot = TelemetrySnapshot.from_mapping({**VALID_SNAPSHOT, "warning": {"level": "unknown"}})
		self.assertIsNone(snapshot.warning)
		snapshot = TelemetrySnapshot.from_mapping({**VALID_SNAPSHOT, "warning": {"level": []}})
		self.assertIsNone(snapshot.warning)

	def test_invalid_mode_is_unavailable(self):
		snapshot = TelemetrySnapshot.from_mapping({**VALID_SNAPSHOT, "ride_mode": []})
		self.assertIsNone(snapshot.ride_mode)


if __name__ == "__main__":
	unittest.main()