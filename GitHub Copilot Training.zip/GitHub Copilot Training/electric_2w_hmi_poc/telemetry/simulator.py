import math
from datetime import datetime, timezone

from .model import TelemetrySnapshot


class TelemetrySimulator:
	def __init__(self, initial_tick: int = 0, ride_mode: str = "RIDE"):
		if not isinstance(ride_mode, str) or ride_mode not in {"ECO", "RIDE", "SPORT"}:
			raise ValueError("Unsupported ride mode")
		self.tick = initial_tick
		self.sequence = 0
		self.ride_mode = ride_mode

	def set_mode(self, ride_mode: str):
		if not isinstance(ride_mode, str) or ride_mode not in {"ECO", "RIDE", "SPORT"}:
			raise ValueError("Unsupported ride mode")
		self.ride_mode = ride_mode

	def next_snapshot(self, now: datetime | None = None):
		self.tick += 1
		self.sequence += 1
		current_time = now or datetime.now(timezone.utc)
		if current_time.tzinfo is None or current_time.utcoffset() != timezone.utc.utcoffset(current_time):
			raise ValueError("now must be a timezone-aware UTC datetime")

		speed = max(0, min(120, int(42 + 16 * math.sin(self.tick / 6))))
		battery = max(0, 78 - self.tick // 60)
		if battery <= 10:
			warning = {"level": "critical", "code": "LOW_BATTERY", "message": "Battery critically low"}
		elif battery <= 20:
			warning = {"level": "caution", "code": "LOW_BATTERY", "message": "Battery low"}
		else:
			warning = {"level": "normal", "code": None, "message": "All systems normal"}

		return TelemetrySnapshot.from_mapping({
			"timestamp": current_time.isoformat().replace("+00:00", "Z"),
			"sequence": self.sequence,
			"source": "simulator",
			"speed_kph": speed,
			"battery_soc_pct": battery,
			"estimated_range_km": int(battery * 1.23),
			"ride_mode": self.ride_mode,
			"regen_level": 2,
			"trip_a_km": 24.6 + self.tick * 0.01,
			"odometer_km": 3842.0 + self.tick * 0.01,
			"consumption_wh_km": 31,
			"left_indicator": self.tick % 36 in {0, 1, 2},
			"right_indicator": self.tick % 36 in {18, 19, 20},
			"headlight_on": True,
			"high_beam_on": False,
			"side_stand_down": False,
			"vehicle_ready": True,
			"connected": True,
			"warning": warning,
		})