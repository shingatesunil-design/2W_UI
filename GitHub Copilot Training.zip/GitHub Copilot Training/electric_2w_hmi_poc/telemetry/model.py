from dataclasses import dataclass
from datetime import datetime, timezone
import math
from typing import Mapping


def _number(data: Mapping[str, object], name: str, maximum: float | None = None):
	value = data.get(name)
	if isinstance(value, bool) or not isinstance(value, (int, float)):
		return None
	if not math.isfinite(value) or value < 0:
		return None
	if maximum is not None and value > maximum:
		return None
	return float(value)


def _boolean(data: Mapping[str, object], name: str):
	value = data.get(name)
	return value if isinstance(value, bool) else None


@dataclass(frozen=True)
class WarningStatus:
	level: str
	code: str | None
	message: str

	@classmethod
	def from_mapping(cls, value: object):
		if not isinstance(value, Mapping):
			return None
		level = value.get("level")
		code = value.get("code")
		message = value.get("message")
		if not isinstance(level, str) or level not in {"normal", "caution", "critical"}:
			return None
		if code is not None and not isinstance(code, str):
			return None
		if not isinstance(message, str):
			return None
		return cls(level=level, code=code, message=message)


@dataclass(frozen=True)
class TelemetrySnapshot:
	timestamp: str
	sequence: int
	source: str
	speed_kph: float | None
	battery_soc_pct: float | None
	estimated_range_km: float | None
	ride_mode: str | None
	regen_level: int | None
	trip_a_km: float | None
	odometer_km: float | None
	consumption_wh_km: float | None
	left_indicator: bool | None
	right_indicator: bool | None
	headlight_on: bool | None
	high_beam_on: bool | None
	side_stand_down: bool | None
	vehicle_ready: bool | None
	connected: bool | None
	warning: WarningStatus | None

	@classmethod
	def from_mapping(cls, data: Mapping[str, object]):
		if not isinstance(data, Mapping):
			raise TypeError("Telemetry snapshot must be a mapping")

		timestamp = data.get("timestamp")
		sequence = data.get("sequence")
		source = data.get("source")
		if not isinstance(timestamp, str):
			raise ValueError("timestamp must be an ISO 8601 UTC string")
		try:
			parsed_timestamp = datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
		except ValueError as error:
			raise ValueError("timestamp must be an ISO 8601 UTC string") from error
		if parsed_timestamp.tzinfo is None or parsed_timestamp.utcoffset() != timezone.utc.utcoffset(parsed_timestamp):
			raise ValueError("timestamp must use UTC")
		if isinstance(sequence, bool) or not isinstance(sequence, int) or sequence < 0:
			raise ValueError("sequence must be a non-negative integer")
		if source != "simulator":
			raise ValueError("source must be 'simulator' for this POC")

		regen_level = data.get("regen_level")
		if isinstance(regen_level, bool) or not isinstance(regen_level, int) or not 0 <= regen_level <= 3:
			regen_level = None

		ride_mode = data.get("ride_mode")
		if not isinstance(ride_mode, str) or ride_mode not in {"ECO", "RIDE", "SPORT"}:
			ride_mode = None

		return cls(
			timestamp=timestamp,
			sequence=sequence,
			source=source,
			speed_kph=_number(data, "speed_kph", 120),
			battery_soc_pct=_number(data, "battery_soc_pct", 100),
			estimated_range_km=_number(data, "estimated_range_km"),
			ride_mode=ride_mode,
			regen_level=regen_level,
			trip_a_km=_number(data, "trip_a_km"),
			odometer_km=_number(data, "odometer_km"),
			consumption_wh_km=_number(data, "consumption_wh_km"),
			left_indicator=_boolean(data, "left_indicator"),
			right_indicator=_boolean(data, "right_indicator"),
			headlight_on=_boolean(data, "headlight_on"),
			high_beam_on=_boolean(data, "high_beam_on"),
			side_stand_down=_boolean(data, "side_stand_down"),
			vehicle_ready=_boolean(data, "vehicle_ready"),
			connected=_boolean(data, "connected"),
			warning=WarningStatus.from_mapping(data.get("warning")),
		)