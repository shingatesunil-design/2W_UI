import math
import sys
from datetime import datetime

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QColor, QFont, QPainter, QPen
from PySide6.QtWidgets import (
	QApplication,
	QFrame,
	QGridLayout,
	QHBoxLayout,
	QLabel,
	QMainWindow,
	QProgressBar,
	QPushButton,
	QSizePolicy,
	QVBoxLayout,
	QWidget,
)


COLORS = {
	"background": "#0a1116",
	"panel": "#111c22",
	"panel_light": "#17262d",
	"line": "#263940",
	"text": "#edf5f3",
	"muted": "#8fa4a8",
	"teal": "#51dfc1",
	"green": "#8be28b",
	"amber": "#f2bd63",
	"red": "#f07171",
}


class SpeedGauge(QWidget):
	def __init__(self, parent=None):
		super().__init__(parent)
		self.speed = 0
		self.setMinimumSize(270, 270)
		self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)

	def set_speed(self, speed):
		self.speed = speed
		self.update()

	def paintEvent(self, event):
		del event
		painter = QPainter(self)
		painter.setRenderHint(QPainter.RenderHint.Antialiasing)
		side = min(self.width(), self.height())
		center = self.rect().center()
		radius = side * 0.39
		arc_rect = self.rect().adjusted(
			int(self.width() / 2 - radius),
			int(self.height() / 2 - radius),
			int(self.width() / 2 + radius),
			int(self.height() / 2 + radius),
		)
		start_angle = 225 * 16
		span_angle = -270 * 16

		painter.setPen(QPen(QColor(COLORS["line"]), max(8, side * 0.028), Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
		painter.drawArc(arc_rect, start_angle, span_angle)

		progress = min(max(self.speed, 0), 120) / 120
		painter.setPen(QPen(QColor(COLORS["teal"]), max(8, side * 0.028), Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
		painter.drawArc(arc_rect, start_angle, int(span_angle * progress))

		for tick in range(13):
			angle = math.radians(135 + tick * 22.5)
			outer = radius + side * 0.05
			inner = radius + side * (0.015 if tick % 3 == 0 else 0.03)
			x1 = center.x() + math.cos(angle) * inner
			y1 = center.y() + math.sin(angle) * inner
			x2 = center.x() + math.cos(angle) * outer
			y2 = center.y() + math.sin(angle) * outer
			painter.setPen(QPen(QColor(COLORS["muted"]), max(1, side * 0.004)))
			painter.drawLine(int(x1), int(y1), int(x2), int(y2))

		painter.setPen(QColor(COLORS["text"]))
		speed_font = QFont("Bahnschrift", max(34, int(side * 0.22)), QFont.Weight.DemiBold)
		painter.setFont(speed_font)
		value_rect = self.rect().adjusted(0, int(side * 0.15), 0, -int(side * 0.07))
		painter.drawText(value_rect, Qt.AlignmentFlag.AlignCenter, str(self.speed))

		painter.setPen(QColor(COLORS["muted"]))
		painter.setFont(QFont("Bahnschrift", max(10, int(side * 0.045)), QFont.Weight.Medium))
		unit_rect = self.rect().adjusted(0, int(side * 0.43), 0, -int(side * 0.01))
		painter.drawText(unit_rect, Qt.AlignmentFlag.AlignCenter, "km/h")


class MetricTile(QFrame):
	def __init__(self, title, value, suffix="", accent=None, parent=None):
		super().__init__(parent)
		self.setObjectName("metricTile")
		layout = QVBoxLayout(self)
		layout.setContentsMargins(16, 12, 16, 12)
		layout.setSpacing(5)

		title_label = QLabel(title.upper())
		title_label.setObjectName("eyebrow")
		self.value_label = QLabel(str(value))
		self.value_label.setObjectName("metricValue")
		if accent:
			self.value_label.setStyleSheet(f"color: {accent};")
		suffix_label = QLabel(suffix)
		suffix_label.setObjectName("metricSuffix")
		layout.addWidget(title_label)
		row = QHBoxLayout()
		row.setSpacing(6)
		row.addWidget(self.value_label)
		row.addWidget(suffix_label, 0, Qt.AlignmentFlag.AlignBottom)
		row.addStretch(1)
		layout.addLayout(row)

	def set_value(self, value):
		self.value_label.setText(str(value))


class StatusLamp(QFrame):
	def __init__(self, symbol, label, active=False, color=None, parent=None):
		super().__init__(parent)
		self.setObjectName("statusLamp")
		self.active = active
		self.color = color or COLORS["teal"]
		layout = QHBoxLayout(self)
		layout.setContentsMargins(10, 8, 10, 8)
		layout.setSpacing(8)
		self.symbol_label = QLabel(symbol)
		self.symbol_label.setObjectName("lampSymbol")
		self.text_label = QLabel(label)
		self.text_label.setObjectName("lampText")
		layout.addWidget(self.symbol_label)
		layout.addWidget(self.text_label)
		self.set_active(active)

	def set_active(self, active):
		self.active = active
		color = self.color if active else COLORS["muted"]
		self.symbol_label.setStyleSheet(f"color: {color}; font-weight: 700;")
		self.text_label.setStyleSheet(f"color: {COLORS['text'] if active else COLORS['muted']};")


class Dashboard(QMainWindow):
	def __init__(self):
		super().__init__()
		self.setWindowTitle("VOLT | Electric Two-Wheeler")
		self.setMinimumSize(980, 600)
		self.resize(1280, 760)
		self.setStyleSheet(f"""
			QWidget {{
				background: {COLORS['background']};
				color: {COLORS['text']};
				font-family: 'Bahnschrift', 'Segoe UI', sans-serif;
			}}
			QFrame#metricTile, QFrame#statusLamp {{
				background: {COLORS['panel']};
				border: 1px solid {COLORS['line']};
				border-radius: 8px;
			}}
			QLabel#eyebrow {{
				color: {COLORS['muted']};
				font-size: 10px;
				font-weight: 700;
				letter-spacing: 1px;
			}}
			QLabel#metricValue {{ font-size: 25px; font-weight: 600; }}
			QLabel#metricSuffix {{ color: {COLORS['muted']}; font-size: 12px; padding-bottom: 3px; }}
			QLabel#lampSymbol {{ font-size: 16px; }}
			QLabel#lampText {{ font-size: 11px; font-weight: 600; }}
			QPushButton {{
				background: {COLORS['panel_light']};
				color: {COLORS['muted']};
				border: 1px solid {COLORS['line']};
				border-radius: 6px;
				padding: 9px 15px;
				font-size: 12px;
				font-weight: 700;
			}}
			QPushButton:checked {{
				background: #173c3a;
				color: {COLORS['teal']};
				border: 1px solid {COLORS['teal']};
			}}
			QProgressBar {{
				background: {COLORS['line']};
				border: none;
				border-radius: 5px;
				text-align: center;
				color: {COLORS['text']};
				height: 12px;
			}}
			QProgressBar::chunk {{ background: {COLORS['green']}; border-radius: 5px; }}
		""")

		self.speed = 42
		self.tick = 0
		self.mode = "RIDE"
		root = QWidget()
		self.setCentralWidget(root)
		layout = QVBoxLayout(root)
		layout.setContentsMargins(26, 20, 26, 20)
		layout.setSpacing(16)
		layout.addLayout(self.build_header())
		layout.addLayout(self.build_status_row())
		layout.addLayout(self.build_main_content(), 1)
		self.speed_gauge.set_speed(self.speed)
		layout.addWidget(self.build_footer())

		self.timer = QTimer(self)
		self.timer.timeout.connect(self.update_telemetry)
		self.timer.start(1000)

	def build_header(self):
		header = QHBoxLayout()
		brand = QVBoxLayout()
		title = QLabel("VOLT  /  E-2W")
		title.setStyleSheet(f"font-size: 17px; font-weight: 800; color: {COLORS['teal']};")
		subtitle = QLabel("ELECTRIC DRIVE SYSTEM")
		subtitle.setObjectName("eyebrow")
		brand.addWidget(title)
		brand.addWidget(subtitle)
		header.addLayout(brand)
		header.addStretch(1)

		self.ready_badge = QLabel("●  VEHICLE READY")
		self.ready_badge.setStyleSheet(f"color: {COLORS['green']}; font-size: 11px; font-weight: 700; padding: 8px 12px; background: {COLORS['panel']}; border-radius: 6px;")
		header.addWidget(self.ready_badge)
		self.clock_label = QLabel(datetime.now().strftime("%H:%M"))
		self.clock_label.setStyleSheet(f"color: {COLORS['muted']}; font-size: 14px; font-weight: 600; margin-left: 12px;")
		header.addWidget(self.clock_label)
		return header

	def build_status_row(self):
		row = QHBoxLayout()
		row.setSpacing(8)
		self.lamps = {
			"left": StatusLamp("◀", "LEFT", False, COLORS["green"]),
			"right": StatusLamp("▶", "RIGHT", False, COLORS["green"]),
			"headlight": StatusLamp("◉", "HEADLIGHT", True, COLORS["teal"]),
			"highbeam": StatusLamp("✦", "HIGH BEAM", False, COLORS["teal"]),
			"stand": StatusLamp("▰", "SIDE STAND UP", True, COLORS["green"]),
			"connection": StatusLamp("⌁", "CONNECTED", True, COLORS["teal"]),
		}
		for lamp in self.lamps.values():
			row.addWidget(lamp)
		return row

	def build_main_content(self):
		main = QHBoxLayout()
		main.setSpacing(18)

		gauge_panel = QFrame()
		gauge_panel.setObjectName("metricTile")
		gauge_layout = QVBoxLayout(gauge_panel)
		gauge_layout.setContentsMargins(20, 16, 20, 16)
		gauge_layout.setSpacing(4)
		gauge_heading = QLabel("ROAD SPEED")
		gauge_heading.setObjectName("eyebrow")
		gauge_layout.addWidget(gauge_heading, 0, Qt.AlignmentFlag.AlignHCenter)
		self.speed_gauge = SpeedGauge()
		gauge_layout.addWidget(self.speed_gauge, 1)
		self.mode_label = QLabel("RIDE MODE  /  RIDE")
		self.mode_label.setStyleSheet(f"color: {COLORS['teal']}; font-size: 11px; font-weight: 700; letter-spacing: 1px;")
		gauge_layout.addWidget(self.mode_label, 0, Qt.AlignmentFlag.AlignHCenter)
		main.addWidget(gauge_panel, 5)

		right = QVBoxLayout()
		right.setSpacing(12)

		battery_panel = QFrame()
		battery_panel.setObjectName("metricTile")
		battery_layout = QVBoxLayout(battery_panel)
		battery_layout.setContentsMargins(18, 14, 18, 14)
		top = QHBoxLayout()
		top.addWidget(QLabel("BATTERY"))
		top.addStretch(1)
		self.battery_percent = QLabel("78%")
		self.battery_percent.setStyleSheet(f"color: {COLORS['green']}; font-size: 26px; font-weight: 700;")
		top.addWidget(self.battery_percent)
		battery_layout.addLayout(top)
		self.battery_bar = QProgressBar()
		self.battery_bar.setRange(0, 100)
		self.battery_bar.setValue(78)
		self.battery_bar.setTextVisible(False)
		battery_layout.addWidget(self.battery_bar)
		battery_bottom = QHBoxLayout()
		battery_bottom.addWidget(QLabel("EST. RANGE"))
		battery_bottom.addStretch(1)
		self.range_label = QLabel("96 km")
		self.range_label.setStyleSheet(f"color: {COLORS['text']}; font-size: 18px; font-weight: 700;")
		battery_bottom.addWidget(self.range_label)
		battery_layout.addLayout(battery_bottom)
		right.addWidget(battery_panel)

		mode_panel = QFrame()
		mode_panel.setObjectName("metricTile")
		mode_layout = QVBoxLayout(mode_panel)
		mode_layout.setContentsMargins(18, 13, 18, 13)
		mode_layout.setSpacing(10)
		mode_title = QLabel("RIDE MODE")
		mode_title.setObjectName("eyebrow")
		mode_layout.addWidget(mode_title)
		buttons = QHBoxLayout()
		buttons.setSpacing(7)
		self.mode_buttons = {}
		for mode in ("ECO", "RIDE", "SPORT"):
			button = QPushButton(mode)
			button.setCheckable(True)
			button.setChecked(mode == self.mode)
			button.clicked.connect(lambda checked, selected=mode: self.set_mode(selected))
			buttons.addWidget(button)
			self.mode_buttons[mode] = button
		mode_layout.addLayout(buttons)
		right.addWidget(mode_panel)

		metrics = QGridLayout()
		metrics.setSpacing(10)
		self.trip_tile = MetricTile("Trip A", "24.6", "km")
		self.odo_tile = MetricTile("Odometer", "3,842", "km")
		self.consumption_tile = MetricTile("Consumption", "31", "Wh/km", COLORS["teal"])
		self.regen_tile = MetricTile("Regen", "LEVEL 2", "", COLORS["green"])
		metrics.addWidget(self.trip_tile, 0, 0)
		metrics.addWidget(self.odo_tile, 0, 1)
		metrics.addWidget(self.consumption_tile, 1, 0)
		metrics.addWidget(self.regen_tile, 1, 1)
		right.addLayout(metrics, 1)
		main.addLayout(right, 6)
		return main

	def build_footer(self):
		footer = QHBoxLayout()
		footer.setContentsMargins(12, 10, 12, 10)
		footer.setSpacing(10)
		warning_icon = QLabel("✓")
		warning_icon.setStyleSheet(f"color: {COLORS['green']}; font-size: 17px; font-weight: 800;")
		warning_text = QLabel("SYSTEM NORMAL")
		warning_text.setStyleSheet(f"color: {COLORS['green']}; font-size: 11px; font-weight: 800; letter-spacing: 1px;")
		detail = QLabel("All vehicle systems operating within normal parameters")
		detail.setStyleSheet(f"color: {COLORS['muted']}; font-size: 11px;")
		footer.addWidget(warning_icon)
		footer.addWidget(warning_text)
		footer.addWidget(detail)
		footer.addStretch(1)
		self.footer_trip = QLabel("TRIP A   24.6 km")
		self.footer_trip.setStyleSheet(f"color: {COLORS['muted']}; font-size: 10px; font-weight: 700;")
		footer.addWidget(self.footer_trip)
		frame = QFrame()
		frame.setStyleSheet(f"background: {COLORS['panel']}; border: 1px solid {COLORS['line']}; border-radius: 7px;")
		frame.setLayout(footer)
		return frame

	def set_mode(self, mode):
		self.mode = mode
		for key, button in self.mode_buttons.items():
			button.setChecked(key == mode)
		self.mode_label.setText(f"RIDE MODE  /  {mode}")

	def update_telemetry(self):
		self.tick += 1
		self.speed = max(0, min(82, int(42 + 16 * math.sin(self.tick / 6))))
		self.speed_gauge.set_speed(self.speed)
		self.clock_label.setText(datetime.now().strftime("%H:%M"))
		battery = 78 - self.tick // 180
		self.battery_percent.setText(f"{battery}%")
		self.battery_bar.setValue(battery)
		self.range_label.setText(f"{int(battery * 1.23)} km")
		self.lamps["left"].set_active(self.tick % 18 in (0, 1, 2))
		self.lamps["right"].set_active(self.tick % 18 in (9, 10, 11))


def main():
	app = QApplication(sys.argv)
	app.setStyle("Fusion")
	window = Dashboard()
	window.show()
	sys.exit(app.exec())


if __name__ == "__main__":
	main()
